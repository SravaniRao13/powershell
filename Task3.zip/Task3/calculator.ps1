﻿##------------Calculator Code---------------#
[char]$b=Read-Host -Prompt 'Enter the Operation you want(+,-,*,/)'
[double]$a=Read-Host -Prompt 'enter the First number'
[double]$c=Read-Host -Prompt 'Enter the Second number'



switch($b)
{
+ {
    [double]$add=$a+$c
    Write-Host("your answer is $add")
    break;
  }
- { 
    [double]$sub=$a-$c
    Write-Host("your answer is $sub")
    break;
  }
*  {
    [double]$multiply=$a*$c
    Write-Host("your answer is $multiply")
    break;
  }
/ {
    [double]$divide=$a/$c
    Write-Host("your answer is $divide")
    break;
  }
% {
    [double]$modulus=$a%$c
    Write-Host("your answer is $modulus")
    break;
  }
  }