﻿##---------Divide by zero----------##
try{
$a=Read-Host 'enter the number' 
$b=Read-Host 'enter the number'
$c=$a/$b
}
catch [System.SystemException]
{
Write-Host " 1/0undefined"
}
finally{
Write-Host "give the correct value "
}





##---------itemnot found exception---------##
try{
Get-Item -Path 'C:\Users\vantaku.sravani\Desktop\powershell'
}
catch
{
Write-Host 'provide correct path'
}
finally
{
Write-Host 'provided correct path'
}

##-------parameter binding validation exception---------##
try{
Get-Item -Path $null
}
catch [System.Management.Automation.ItenNotFoundException]{
Write-Host -Object 'item specified not found'
}
catch [ParameterBindingValidationException] {
Write- Host 'Parameter Binding has failed'
}
finally {
Write-Host -Object 'Closing all open file handles'
}