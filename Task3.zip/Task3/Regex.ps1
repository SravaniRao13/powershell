﻿$data = Read-Host "Enter your Choice(aadharno,creditno,pan,date,ip)"

switch ($data)
    {
 aadharno   {
        $a=Read-Host -Prompt 'enter the number'
        if( $a -match '\d\d\d\d-\d\d\d\d-\d\d\d\d' )
        {
        Write-Output "It is a Aadhar Number"
        }
        else
        {
        Write-Warning 'message may not contain a aadhar card number'
        }
}
creditno {
        $b=Read-Host -Prompt 'Enter the number'
        if($b -match '\d\d\d\d-\d\d\d\d-\d\d\d\d-\d\d\d\d' )
{
Write-Output "It is a Credit card Number"
}
else
{
write-Warning 'message may not contain a credit card number'
}
}
pan {
     $c=Read-Host -Prompt 'enter the PAN Number'
     if( $c -cmatch "[A-Z]{5}[0-9]{4}[A-Z]{1}" )
        {
        Write-Output "It is a PAN Number"
        }
        else
        {
        Write-Warning 'message may not contain a PAN number'
        }
}
date {
        $d=Read-Host -Prompt 'enter the Date'
        if ($d = [Regex]::new('\d\d\d\d-\d\d-\d\d'))
       {
       $matches = $d.Matches($d)
       $matches.Value
         Write-Output "The Input you entered is DATE Format"
        }
        else
        {
        Write-Warning 'message Invalied Date Format'
        }
}
ip {
      $e=Read-Host -Prompt 'enter the IP'
      if( $e -match '[0-9]{1-3}.[0-9]{1-3}.[0-9]{1-3}.[0-9]{1-3}' )
        {
        Write-Output "It is an IP Addressr"
        }
        else
        {
        Write-Warning 'Enter Proper IP'
        }
}
}
   
 ##'\d\d\d\d-\d\d\d\d-\d\d\d\d-\d\d\d\d' {
   ##         Write-Warning 'message may contain a credit card number'
    ##    }
      ##  '\d\d\d-\d\d\d-\d\d\d\d' {
        ##    Write-Warning 'message may contain a phone number'
        ##}
    ##}
