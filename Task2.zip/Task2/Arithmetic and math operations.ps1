##------------Calculator Code---------------#
[char]$b=Read-Host -Prompt 'Enter the Operation you want(+,-,*,/)'
[double]$a=Read-Host -Prompt 'enter the First number'
[double]$c=Read-Host -Prompt 'Enter the Second number'
[double]$add=$a+$c
[double]$sub=$a-$c
[double]$multiply=$a*$c
[double]$divide=$a/$c
[double]$modulus=$a%$c

switch($b)
{
+{$result = 'you Choosen Addition'
   Write-Host("your answer is $add")
   break;
  }
  +{$result = 'you Choosen Subtraction'
   Write-Host("your answer is $sub")
   break;
  }
  +{$result = 'you Choosen Multiplication'
   Write-Host("your answer is $multiply")
   break;
  }
  +{$result = 'you Choosen Divide'
   Write-Host("your answer is $divide")
   break;
  }
  +{$result = 'you Choosen Modulus'
   Write-Host("your answer is $modulus")
   break;
  }
  }
#------------log(), sin (),cos(),tan(), squareroot---------------#
[Math]::Sqrt(100)
[Math]::Sin( [Math]::PI / 2 ) 
[Math]::Asin(1)
[Math]::Sin(2)
[Math]::AcOs(1)
[Math]::Atan(1)