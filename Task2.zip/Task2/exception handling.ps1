##---------Divide by zero----------##
try{
$c=1/0
}
catch [System.SystemException]
{
Write-Host " 1/0undefined"
}
finally{
Write-Host "finally "
}
##-------Item not found exception------###
try{
Get-Item -Path 'C:\Users\vantaku.sravani\Desktop\ps'
}
catch
{
Write-Host 'provide correct path'
}
finally
{
Write-Host 'provided correct path'
}
##-------parameter binding validation exception---------##
try{
Get-Item -Path $null
}
catch [System.Management.Automation.ItenNotFoundException]{
Write-Host -Object 'item specified not found'
}
catch [ParameterBindingValidationException] {
Write- Host 'Parameter Binding has failed'
}
finally {
Write-Host -Object 'Closing all open file handles'
}