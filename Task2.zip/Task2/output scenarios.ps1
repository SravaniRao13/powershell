#----------------Files and Folders-----------------#

#create directory
New-Item -Path 'C:\Users\vantaku.sravani\Desktop\powershell\TestFolder' -ItemType Directory
#Creating File
New-Item -Path 'C:\Users\vantaku.sravani\Desktop\powershell\Testfile.txt' -ItemType File
#Copying Folder
Copy-Item 'C:\Users\vantaku.sravani\Desktop\powershell\TestFolder' 'C:\Users\vantaku.sravani\Desktop\powershell\TestFolder1'
#Copying File
Copy-Item 'C:\Users\vantaku.sravani\Desktop\powershell\new.txt' 'C:\Users\vantaku.sravani\Desktop\powershell\new1.txt'
#Delete Directory
Remove-Item 'C:\Users\vantaku.sravani\Desktop\powershell\TestFolder'
#Delete File
Remove-Item 'C:\Users\vantaku.sravani\Desktop\powershell\test.txt'
#Moving Directory
Move-Item 'C:\Users\vantaku.sravani\Desktop\powershell\new C:\Users\vantaku.sravani\Desktop\Powershell\new1'
#Moving File
Move-Item 'C:\Users\vantaku.sravani\Desktop\powershell\new.txt C:\Users\vantaku.sravani\Desktop\Powershell\new1.txt'
#Rename Directory
Rename-Item 'C:\Users\vantaku.sravani\Desktop\powershell\test C:\Users\vantaku.sravani\Desktop\powershell\test1'
#Rename File
Rename-Item 'C:\Users\vantaku.sravani\Desktop\powershell\test.txt test1.txt'
#Retreiving the Item
Get-Content C:\Users\vantaku.sravani\Desktop\powershell\test.txt
#Check Directory Existence
Test-Path 'C:\Users\vantaku.sravani\Desktop\powershell'
#Check File Existence
Test-Path 'C:\Users\vantaku.sravani\Desktop\powershell\test.txt'
# -------Working with the output Scenarios---------#
#create file
New-Item C:\Users\test\test.txt
#Add Content
Set-Content D:\temp\test\test.txt 'Welcome to PowerShell'
#Read file
get-Content D:\temp\test\test.txt
#Create XML File
New-Item D:\temp\test\test.xml -ItemType File
#Add Content into XML File
Set-Content D:\temp\test\test.xml '<title>Welcome to PowerShell</title>'
#Read XML File
Get-Content D:\temp\test\test.xml
#Create CSV File
New-Item D:\temp\test\test.csv -ItemType File
#Add Content into CSV File
Set-Content D:\temp\test\test.csv 'Mahesh,Suresh,Ramesh'
#Read CSV File
Get-Content D:\temp\test\test.csv
#Create HTML File
New-Item D:\temp\test\test.html -ItemType File
#Add Content into HTML File
Set-Content D:\temp\test\test.html '<html>Welcome to Powershell</html>'
#Read HTML File
Get-Content D:\temp\test\test.html
#Erasing FileContent
Clear-Content D:\temp\test\test.txt
#Appending Text Data
Set-Content D:\temp\test\test.txt 'Hello'
Add-Content D:\temp\test\test.txt 'World!'
Get-Content D:\temp\test\test.txt