##Array
$myList = @(0..4)

write-host("Print array")
$myList